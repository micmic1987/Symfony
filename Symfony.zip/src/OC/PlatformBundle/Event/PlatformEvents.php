<?php

namespace OC\PlatformBundle\Event;

final class PlatformEvents
{
  const POST_MESSAGE = 'oc_platform.post_message';
}